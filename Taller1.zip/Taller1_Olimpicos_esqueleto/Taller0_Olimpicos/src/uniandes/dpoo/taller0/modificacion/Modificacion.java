package uniandes.dpoo.taller0.modificacion;

import java.io.FileNotFoundException;
import java.io.IOException;

import uniandes.dpoo.taller0.procesamiento.CalculadoraEstadisticas;
import uniandes.dpoo.taller0.procesamiento.LoaderOlimpicos;

public class Modificacion {
    private CalculadoraEstadisticas calculadoraEstadisticas;

    private Modificacion() throws FileNotFoundException, IOException {
        this.calculadoraEstadisticas = LoaderOlimpicos.cargarArchivo("data/atletas.csv");
    }

    private void imprimirConMasMedallas() {
        System.out.println(this.calculadoraEstadisticas.paisConMasMedallistas());
    }

    public static void main(String[] args) throws FileNotFoundException, IOException {
        Modificacion modificacion = new Modificacion();
        
        modificacion.imprimirConMasMedallas();
    }
}

